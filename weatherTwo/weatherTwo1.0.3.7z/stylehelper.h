#ifndef STYLEHELPER_H
#define STYLEHELPER_H
#include "qdebug.h"
#include <QFile>
#include <QString>



class StyleHelper
{
public:
    static QString getStyle();
    static QString getFontColor();
};

#endif // STYLEHELPER_H
